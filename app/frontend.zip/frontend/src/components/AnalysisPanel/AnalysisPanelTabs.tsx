export enum AnalysisPanelTabs {
    Monitoring = "monitoring",
    ThoughtProcessTab = "thoughtProcess",
    SupportingContentTab = "supportingContent",
    CitationTab = "citation"
}
